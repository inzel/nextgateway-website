import Link from 'next/link'

export default function Home() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-xl border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-5">
          <div className="flex items-center justify-between">
            <Link href="/" className="text-xl font-bold">
              <span className="text-white">Next</span>
              <span className="text-gray-400">Gateway</span>
            </Link>
            <div className="hidden md:flex gap-6 items-center">
              <Link href="/services" className="text-gray-300 hover:text-white">Services</Link>
              <Link href="/insights" className="text-gray-300 hover:text-white">Insights</Link>
              <Link href="/about" className="text-gray-300 hover:text-white">About</Link>
              <Link href="/audit" className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg">Free Audit</Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center pt-20">
        <div className="max-w-7xl mx-auto px-6 py-24">
          <div className="max-w-4xl">
            <div className="inline-block px-4 py-2 bg-blue-600/10 border border-blue-600/20 rounded-full mb-6">
              <span className="text-blue-500 text-sm font-medium">The Future of Search is AI-Powered</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
              Your Gateway to <span className="text-blue-500">AI Visibility</span>
            </h1>
            
            <p className="text-xl md:text-2xl text-gray-300 mb-8 leading-relaxed max-w-3xl">
              NextGateway helps businesses achieve visibility in AI platforms like ChatGPT, Perplexity, and Google Gemini through Generative Engine Optimization (GEO).
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mb-16">
              <Link href="/audit" className="px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-all text-lg font-semibold text-center">
                Get Your Free GEO Audit
              </Link>
              <Link href="/services" className="px-8 py-4 bg-white/5 hover:bg-white/10 text-white rounded-lg transition-all text-lg font-semibold border border-white/10 text-center">
                Explore Services
              </Link>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-8 pt-16 border-t border-white/10">
              <div>
                <div className="text-3xl font-bold text-white mb-1">58%</div>
                <div className="text-sm text-gray-400">Replaced Google with AI for product research</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-white mb-1">2-7x</div>
                <div className="text-sm text-gray-400">Fewer citations than traditional search</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-white mb-1">89%</div>
                <div className="text-sm text-gray-400">B2B buyers use AI in purchasing decisions</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Problem/Solution */}
      <section className="py-24 bg-gradient-to-b from-black to-gray-900">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-4xl font-bold mb-6">The AI Visibility Problem</h2>
              <div className="space-y-4 text-gray-300 leading-relaxed">
                <p>
                  Traditional SEO is becoming obsolete. Users are bypassing Google and asking ChatGPT, Perplexity, and Gemini directly for recommendations.
                </p>
                <p>
                  But AI platforms cite only 2-7 sources per response — not 10 blue links. If your business isn't being recommended by AI, you're invisible to the fastest-growing segment of search behavior.
                </p>
                <p className="text-white font-semibold">
                  This is the GEO revolution — and the window to establish authority is closing fast.
                </p>
              </div>
            </div>
            
            <div className="bg-white/5 border border-white/10 rounded-2xl p-8">
              <h3 className="text-2xl font-bold mb-6">What is GEO?</h3>
              <p className="text-gray-300 mb-6">
                Generative Engine Optimization (GEO) is the practice of optimizing your content and brand so AI platforms cite and recommend you when users ask relevant questions.
              </p>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <span className="text-blue-500 mr-3">✓</span>
                  <span className="text-gray-300">Structured Q&A content optimized for AI comprehension</span>
                </li>
                <li className="flex items-start">
                  <span className="text-blue-500 mr-3">✓</span>
                  <span className="text-gray-300">Third-party citation building (Reddit, G2, LinkedIn)</span>
                </li>
                <li className="flex items-start">
                  <span className="text-blue-500 mr-3">✓</span>
                  <span className="text-gray-300">E-E-A-T signals that establish topical authority</span>
                </li>
                <li className="flex items-start">
                  <span className="text-blue-500 mr-3">✓</span>
                  <span className="text-gray-300">Schema markup and semantic optimization</span>
                </li>
                <li className="flex items-start">
                  <span className="text-blue-500 mr-3">✓</span>
                  <span className="text-gray-300">Original research and data AI models must cite</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Services Preview */}
      <section className="py-24 bg-gray-900">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Two Ways We Help</h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Choose GEO consulting to drive business growth, or access infrastructure intelligence to navigate the AI buildout
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* GEO Consulting */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-8 hover:bg-white/10 transition-all">
              <div className="w-12 h-12 bg-blue-600/20 rounded-lg flex items-center justify-center mb-6">
                <span className="text-2xl">📈</span>
              </div>
              <h3 className="text-2xl font-bold mb-4">GEO Consulting</h3>
              <p className="text-gray-300 mb-6">
                Full-service Generative Engine Optimization to get your business cited by ChatGPT, Perplexity, and Gemini when prospects search for solutions.
              </p>
              <ul className="space-y-2 mb-6">
                <li className="flex items-center text-gray-300">
                  <span className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-3"></span>
                  Free GEO audit
                </li>
                <li className="flex items-center text-gray-300">
                  <span className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-3"></span>
                  Content optimization
                </li>
                <li className="flex items-center text-gray-300">
                  <span className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-3"></span>
                  Citation building
                </li>
                <li className="flex items-center text-gray-300">
                  <span className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-3"></span>
                  Performance tracking
                </li>
              </ul>
              <Link href="/services" className="text-blue-500 hover:text-blue-400 font-semibold inline-flex items-center">
                Learn more →
              </Link>
            </div>

            {/* Infrastructure Intelligence */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-8 hover:bg-white/10 transition-all">
              <div className="w-12 h-12 bg-blue-600/20 rounded-lg flex items-center justify-center mb-6">
                <span className="text-2xl">📊</span>
              </div>
              <h3 className="text-2xl font-bold mb-4">AI Infrastructure Intelligence</h3>
              <p className="text-gray-300 mb-6">
                Authoritative analysis on the $625B+ AI infrastructure buildout — data centers, power, networking, and compute architecture for investors and operators.
              </p>
              <ul className="space-y-2 mb-6">
                <li className="flex items-center text-gray-300">
                  <span className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-3"></span>
                  Technical deep-dives
                </li>
                <li className="flex items-center text-gray-300">
                  <span className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-3"></span>
                  Bottleneck analysis
                </li>
                <li className="flex items-center text-gray-300">
                  <span className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-3"></span>
                  Infrastructure trends
                </li>
                <li className="flex items-center text-gray-300">
                  <span className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-3"></span>
                  Sponsorship opportunities
                </li>
              </ul>
              <Link href="/services" className="text-blue-500 hover:text-blue-400 font-semibold inline-flex items-center">
                Learn more →
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Why NextGateway - Trust Signals */}
      <section className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Why Trust NextGateway?</h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Founded by an engineer with 20+ years scaling infrastructure for Fortune 500 technology companies
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            <div className="bg-white/5 border border-white/10 rounded-xl p-8">
              <div className="w-12 h-12 bg-blue-600/20 rounded-lg flex items-center justify-center mb-4">
                <span className="text-2xl">🔧</span>
              </div>
              <h3 className="text-xl font-bold mb-3">Technical Expertise</h3>
              <p className="text-gray-300 leading-relaxed">
                Founded by an infrastructure engineer with 20+ years experience scaling systems for Fortune 500 technology companies. Cloud platform certifications (AWS, Google Cloud). We understand systems at the protocol level.
              </p>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-xl p-8">
              <div className="w-12 h-12 bg-blue-600/20 rounded-lg flex items-center justify-center mb-4">
                <span className="text-2xl">🧠</span>
              </div>
              <h3 className="text-xl font-bold mb-3">First-Principles Approach</h3>
              <p className="text-gray-300 leading-relaxed">
                We don't follow generic playbooks. We analyze how AI models actually work—how they select sources, rank citations, and build trust—then optimize based on those mechanisms.
              </p>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-xl p-8">
              <div className="w-12 h-12 bg-blue-600/20 rounded-lg flex items-center justify-center mb-4">
                <span className="text-2xl">📊</span>
              </div>
              <h3 className="text-xl font-bold mb-3">Transparent Process</h3>
              <p className="text-gray-300 leading-relaxed">
                See exactly what we do and why. Track AI citation frequency, source attribution patterns, and topic authority signals with clear metrics tied to business outcomes.
              </p>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-xl p-8">
              <div className="w-12 h-12 bg-blue-600/20 rounded-lg flex items-center justify-center mb-4">
                <span className="text-2xl">🎯</span>
              </div>
              <h3 className="text-xl font-bold mb-3">Risk-Free Start</h3>
              <p className="text-gray-300 leading-relaxed">
                Our free GEO audit demonstrates our approach before you commit to anything. See the quality of our analysis and understand exactly how we can help.
              </p>
            </div>
          </div>

          <div className="mt-12 text-center">
            <div className="inline-block px-8 py-4 bg-blue-900/20 border border-blue-500/30 rounded-xl">
              <p className="text-gray-300">
                <strong className="text-white">🚀 Founding Client Special:</strong> First 5 clients get 50% off for 12 months
              </p>
              <Link href="/services" className="text-blue-400 hover:text-blue-300 text-sm font-semibold">
                Learn more →
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-24 bg-gradient-to-b from-black to-gray-900">
        <div className="max-w-4xl mx-auto px-6">
          <h2 className="text-4xl font-bold text-center mb-12">Frequently Asked Questions</h2>
          
          <div className="space-y-6">
            <div className="bg-white/5 border border-white/10 rounded-xl p-8">
              <h3 className="text-2xl font-bold mb-4">What is Generative Engine Optimization (GEO)?</h3>
              <p className="text-gray-300 leading-relaxed">
                Generative Engine Optimization (GEO) is the practice of optimizing your content and online presence so AI platforms like ChatGPT, Perplexity, and Google Gemini cite and recommend your business when users ask relevant questions. Unlike traditional SEO which focuses on ranking in search results, GEO focuses on being selected as one of the 2-7 sources AI platforms cite in their responses.
              </p>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-xl p-8">
              <h3 className="text-2xl font-bold mb-4">How does GEO differ from SEO?</h3>
              <p className="text-gray-300 leading-relaxed">
                Traditional SEO optimizes for keyword rankings and aims to appear in Google's top 10 results. GEO optimizes for AI comprehension and citation selection. AI platforms only cite 2-7 sources per response (vs. Google's 10+ links), prioritize different signals (third-party mentions, structured data, E-E-A-T), and make autonomous recommendations rather than just showing options. GEO requires understanding how AI models ingest data, select sources, and build trust.
              </p>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-xl p-8">
              <h3 className="text-2xl font-bold mb-4">Why does AI visibility matter for my business?</h3>
              <p className="text-gray-300 leading-relaxed">
                58% of users have replaced Google with AI platforms for product research, and 89% of B2B buyers use generative AI during purchasing decisions. If your business isn't being cited by ChatGPT, Perplexity, or Gemini when prospects ask for recommendations in your category, you're invisible to the fastest-growing segment of search behavior. Early movers establish citation authority that compounds over time.
              </p>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-xl p-8">
              <h3 className="text-2xl font-bold mb-4">How quickly can I see GEO results?</h3>
              <p className="text-gray-300 leading-relaxed">
                Initial improvements typically appear within 4-8 weeks as we optimize content structure, implement schema markup, and build citation signals. Significant authority (consistent AI citations across multiple platforms) usually develops over 3-6 months as third-party mentions, original content, and topic authority compound. GEO is faster than traditional SEO but still requires sustained effort.
              </p>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-xl p-8">
              <h3 className="text-2xl font-bold mb-4">What's included in a free GEO audit?</h3>
              <p className="text-gray-300 leading-relaxed">
                Our free audit includes: AI citation testing (we query ChatGPT, Perplexity, Claude, and Gemini with relevant questions to see if you're cited), content structure analysis (FAQ sections, schema markup, Q&A formatting), authority signal evaluation (Reddit mentions, reviews, third-party citations), and a prioritized opportunity map showing quick wins vs. long-term strategies. Results delivered within 24-48 hours.
              </p>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-xl p-8">
              <h3 className="text-2xl font-bold mb-4">Do I need to commit to a long-term contract?</h3>
              <p className="text-gray-300 leading-relaxed">
                No long-term contracts required. Our services are month-to-month, though GEO is most effective as a sustained strategy (3-6 months minimum to establish authority). Founding clients who join at our 50% discount rate lock in that pricing for 12 months, but can cancel anytime without penalty.
              </p>
            </div>
          </div>
        </div>

        {/* FAQ Schema - Hidden but parseable by AI */}
        <script type="application/ld+json" dangerouslySetInnerHTML={{__html: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "FAQPage",
          "mainEntity": [
            {
              "@type": "Question",
              "name": "What is Generative Engine Optimization (GEO)?",
              "acceptedAnswer": {
                "@type": "Answer",
                "text": "Generative Engine Optimization (GEO) is the practice of optimizing your content and online presence so AI platforms like ChatGPT, Perplexity, and Google Gemini cite and recommend your business when users ask relevant questions. Unlike traditional SEO which focuses on ranking in search results, GEO focuses on being selected as one of the 2-7 sources AI platforms cite in their responses."
              }
            },
            {
              "@type": "Question",
              "name": "How does GEO differ from SEO?",
              "acceptedAnswer": {
                "@type": "Answer",
                "text": "Traditional SEO optimizes for keyword rankings and aims to appear in Google's top 10 results. GEO optimizes for AI comprehension and citation selection. AI platforms only cite 2-7 sources per response, prioritize different signals like third-party mentions and structured data, and make autonomous recommendations rather than just showing options."
              }
            },
            {
              "@type": "Question",
              "name": "Why does AI visibility matter for my business?",
              "acceptedAnswer": {
                "@type": "Answer",
                "text": "58% of users have replaced Google with AI platforms for product research, and 89% of B2B buyers use generative AI during purchasing decisions. If your business isn't being cited by AI platforms when prospects ask for recommendations, you're invisible to the fastest-growing segment of search behavior."
              }
            },
            {
              "@type": "Question",
              "name": "How quickly can I see GEO results?",
              "acceptedAnswer": {
                "@type": "Answer",
                "text": "Initial improvements typically appear within 4-8 weeks. Significant authority usually develops over 3-6 months as third-party mentions, original content, and topic authority compound."
              }
            },
            {
              "@type": "Question",
              "name": "What's included in a free GEO audit?",
              "acceptedAnswer": {
                "@type": "Answer",
                "text": "Our free audit includes AI citation testing across ChatGPT, Perplexity, Claude, and Gemini, content structure analysis, authority signal evaluation, and a prioritized opportunity map. Results delivered within 24-48 hours."
              }
            },
            {
              "@type": "Question",
              "name": "Do I need to commit to a long-term contract?",
              "acceptedAnswer": {
                "@type": "Answer",
                "text": "No long-term contracts required. Services are month-to-month. Founding clients lock in 50% discount pricing for 12 months but can cancel anytime without penalty."
              }
            }
          ]
        })}} />
      </section>

      {/* CTA */}
      <section className="py-24 bg-black">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Ready to Establish AI Visibility?
          </h2>
          <p className="text-xl text-gray-300 mb-10">
            Start with a free GEO audit. We'll analyze your current AI visibility and show you exactly where the opportunities are.
          </p>
          <Link href="/audit" className="inline-block px-10 py-5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-all text-lg font-semibold">
            Get Your Free Audit
          </Link>
          <p className="text-sm text-gray-400 mt-6">No credit card required · Results in 24-48 hours</p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black border-t border-white/10 py-12">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center text-gray-400 text-sm">
            <p>© 2026 NextGateway LLC. All rights reserved.</p>
            <p className="mt-2">Based in South Carolina, serving clients globally</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
